const preguntas = [
    {
        pregunta: "¿Cuál es el lenguaje de marcado utilizado para crear páginas web?",
        opciones: ["JavaScript", "HTML", "CSS", "Python"],
        respuesta: "HTML"
    },
    {
        pregunta: "¿Cuál es el símbolo para seleccionar un elemento por clase en CSS?",
        opciones: [".", "#", "*", "&"],
        respuesta: "."
    },
    {
        pregunta: "¿Qué método se utiliza para añadir un elemento al final de un array en JavaScript?",
        opciones: ["push()", "pop()", "shift()", "unshift()"],
        respuesta: "push()"
    },
    {
        pregunta: "¿Qué propiedad en CSS se utiliza para cambiar el color de fondo de un elemento?",
        opciones: ["background-color", "color", "border", "background-image"],
        respuesta: "background-color"
    },
    {
        pregunta: "¿Cuál es el método en JavaScript que se utiliza para seleccionar un elemento por su id?",
        opciones: ["getElementByClassName", "querySelector", "getElementById", "getElementsByTagName"],
        respuesta: "getElementById"
    },
    {
        pregunta: "¿Qué etiqueta HTML se usa para enlazar un archivo CSS externo?",
        opciones: ["<link>", "<style>", "<script>", "<meta>"],
        respuesta: "<link>"
    }
];

let preguntaActual = 0;
let puntaje = 0;
let opcionSeleccionada = null;
let tiempoRestante = 30;
let temporizadorInterval;

const inicioPantalla = document.getElementById('inicio');
const comenzarBtn = document.getElementById('comenzar-btn');
const preguntasPantalla = document.getElementById('preguntas');
const preguntaTexto = document.getElementById('pregunta-texto');
const opcionesLista = document.getElementById('opciones-lista');
const siguienteBtn = document.getElementById('siguiente-btn');
const resultadosPantalla = document.getElementById('resultados');
const puntajeFinal = document.getElementById('puntaje-final');
const totalPreguntas = document.getElementById('total-preguntas');
const mensajeFinal = document.getElementById('mensaje-final');
const retroalimentacion = document.getElementById('retroalimentacion');
const barraProgreso = document.getElementById('barra-progreso');
const tiempoRestanteElem = document.getElementById('tiempo-restante');
const reiniciarBtn = document.getElementById('reiniciar-btn');

comenzarBtn.addEventListener('click', () => {
    console.log("Botón Comenzar clicado"); // Esto te dirá si el evento está ocurriendo
    inicioPantalla.classList.add('ocultar');
    preguntasPantalla.classList.remove('ocultar');
    mostrarPregunta();
    iniciarTemporizador();
});

siguienteBtn.addEventListener('click', () => {
    console.log("Botón Siguiente clicado");
    pausarTemporizador();
    verificarRespuesta();
    avanzarPregunta();
});

function mostrarPregunta() {
    const pregunta = preguntas[preguntaActual];
    preguntaTexto.textContent = pregunta.pregunta;
    opcionesLista.innerHTML = '';

    pregunta.opciones.forEach(opcion => {
        const li = document.createElement('li');
        li.textContent = opcion;
        li.classList.add('opcion');
        li.addEventListener('click', seleccionarOpcion);
        opcionesLista.appendChild(li);
    });

    actualizarBarraProgreso();
}

function seleccionarOpcion(e) {
    const opciones = document.querySelectorAll('.opcion');
    opciones.forEach(op => op.classList.remove('seleccionado'));

    e.target.classList.add('seleccionado');
    opcionSeleccionada = e.target.textContent;
}

function verificarRespuesta() {
    const pregunta = preguntas[preguntaActual];
    if (opcionSeleccionada === pregunta.respuesta) {
        puntaje++;
        mostrarRetroalimentacion(true);
    } else {
        mostrarRetroalimentacion(false);
    }
    opcionSeleccionada = null;
}

function avanzarPregunta() {
    preguntaActual++;
    if (preguntaActual < preguntas.length) {
        mostrarPregunta();
        iniciarTemporizador();
    } else {
        mostrarResultados();
    }
}

function mostrarRetroalimentacion(esCorrecto) {
    retroalimentacion.classList.remove('ocultar');
    retroalimentacion.textContent = esCorrecto ? "¡Correcto!" : `Incorrecto. La respuesta correcta era: ${preguntas[preguntaActual - 1].respuesta}`;
    retroalimentacion.classList.add(esCorrecto ? 'correcto' : 'incorrecto');
    setTimeout(() => {
        retroalimentacion.classList.add('ocultar');
        retroalimentacion.classList.remove('correcto', 'incorrecto');
    }, 2000);
}

function mostrarResultados() {
    preguntasPantalla.classList.add('ocultar');
    resultadosPantalla.classList.remove('ocultar');
    puntajeFinal.textContent = puntaje;
    totalPreguntas.textContent = preguntas.length;
    const porcentaje = (puntaje / preguntas.length) * 100;
    mensajeFinal.textContent = porcentaje === 100
        ? "¡Excelente! Respondiste todas las preguntas correctamente."
        : porcentaje >= 70
            ? "¡Muy bien! Tienes un buen conocimiento."
            : "Necesitas mejorar.";
}

function iniciarTemporizador() {
    tiempoRestante = 30;
    tiempoRestanteElem.textContent = tiempoRestante;
    temporizadorInterval = setInterval(() => {
        tiempoRestante--;
        tiempoRestanteElem.textContent = tiempoRestante;
        if (tiempoRestante <= 0) {
            clearInterval(temporizadorInterval);
            avanzarPregunta();
        }
    }, 1000);
}

function pausarTemporizador() {
    clearInterval(temporizadorInterval);
}

function actualizarBarraProgreso() {
    const porcentaje = ((preguntaActual) / preguntas.length) * 100;
    barraProgreso.style.width = `${porcentaje}%`;
}
document.getElementById('comenzar-btn').addEventListener('click', function () {
    alert('Botón Comenzar Funciona');
});
reiniciarBtn.addEventListener('click', reiniciarQuiz);
function reiniciarQuiz() {
    resultadosPantalla.classList.add('ocultar');
    inicioPantalla.classList.remove('ocultar');
    preguntaActual = 0;
    puntaje = 0;
    opcionSeleccionada = null;
}

